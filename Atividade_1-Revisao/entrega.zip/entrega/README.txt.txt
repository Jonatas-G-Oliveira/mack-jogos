Nome:Jônatas Garcia de Oliveira RA:10396490
Olá professor!

Na primeira pasta <implementação_1_2> estão as duas primeiras questões.
Na segunda pasta <implementação_3> está a 3ª questão.

Desde já agradeço a atenção ;)