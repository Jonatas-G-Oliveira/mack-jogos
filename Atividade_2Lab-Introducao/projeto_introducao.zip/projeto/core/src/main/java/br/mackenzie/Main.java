package br.mackenzie;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;


public class Main implements ApplicationListener {
    Texture spaceshipTexture;
    SpriteBatch spriteBatch;
    FitViewport viewport;
    Sprite spaceshipSprite;

    @Override
    public void create() {
        // Prepare your application here.
        spaceshipTexture = new Texture("spaceship.png");
        spriteBatch = new SpriteBatch();
        viewport = new FitViewport(8, 5);

        spaceshipSprite = new Sprite(spaceshipTexture);
        spaceshipSprite.setSize(1, 1);
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);

    }

    @Override
    public void render() {
        // Draw your application here.
        input();
        logic();
        draw();
    }

    private void input(){
        float speed = 4f;
        float delta = Gdx.graphics.getDeltaTime();

        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            spaceshipSprite.translateX(speed * delta);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            spaceshipSprite.translateX(-speed * delta);
        }
         if(Gdx.input.isKeyPressed(Input.Keys.UP)){
            spaceshipSprite.translateY(speed * delta);
        }
         if(Gdx.input.isKeyPressed(Input.Keys.DOWN)){
            spaceshipSprite.translateY(-speed * delta);
        }
       
    }
    private void logic(){

    }
    private void draw(){
        ScreenUtils.clear(Color.BLACK);
        viewport.apply();
        spriteBatch.setProjectionMatrix(viewport.getCamera().combined);
        spriteBatch.begin();
        spaceshipSprite.draw(spriteBatch);
        spriteBatch.end();
    }
    @Override
    public void pause() {
        // Invoked when your application is paused.
    }

    @Override
    public void resume() {
        // Invoked when your application is resumed after pause.
    }

    @Override
    public void dispose() {
        // Destroy application's resources here.
    }
}